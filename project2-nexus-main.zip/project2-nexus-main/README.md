A fabulous website design for the company techy software with a variety of features and responsiveness with the help of bootstrap css. 
